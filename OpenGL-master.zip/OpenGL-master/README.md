# **Causes of cancer and its effects** :syringe:

## This was our Computer graphics mini project in 6th semester :school_satchel:. Built with graphics library OpenGL. 
 
 Contains 4 scenes :movie_camera:
 

  - Uncontrollable division of cells
  - Benign and Melignant tumor
  - Spread of cancer cells across the body through blood vessels
  - Differennt external causes for cancer
 
### It was great fun building this project thanks to my project partner <a href="https://github.com/Diksha94"> Diksha </a> :raised_hands:


# **Sceen Shots**

## Intro Scene
 
 <img src="https://github.com/abhishekori/OpenGL/blob/master/Screenshot_4.png">
 
## Scene one
 <img src="https://github.com/abhishekori/OpenGL/blob/master/Screenshot_5.png">
## Scene two
 <img src="https://github.com/abhishekori/OpenGL/blob/master/Screenshot_6.png" >
## Scene three
 <img src="https://github.com/abhishekori/OpenGL/blob/master/Screenshot_7.png">
 
## Scene four
 <img src="https://github.com/abhishekori/OpenGL/blob/master/Screenshot_8.png" >
 
### Our Project report and corresponding resources  
<a href="https://github.com/abhishekori/OpenGL/blob/master/final%20report.zip">Report</a> 
 
